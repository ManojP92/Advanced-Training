package problem11;

import java.util.Scanner;

public class EvenNumbers {
public static void main(String[] args) {
	System.out.println("Enter number: ");
	Scanner sc= new Scanner(System.in);
	int n= sc.nextInt();
	int even=0;
	for(int i=1;i<=n;i++)
	{
		even=i;
		int check=even%2;
		if(check==0)
			System.out.print(" "+even);
			
	}
	System.out.println("\n These are the even numbers till "+n);
	sc.close();
}
}

