package problem21;

import java.util.Scanner;

public class Strcmd {
	public static void main(String args[])
	   {
	      String str, upper, rev = "";
	      Scanner sc = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str = sc.nextLine();
	
	      int length = str.length();
	      System.out.println("Length of entered string is: "+length);
	      
	      upper=str.toUpperCase();
	      System.out.println("Upper case: "+upper);
	      
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + str.charAt(i);
	 
	      if (str.equals(rev))
	         System.out.println(str+" is a palindrome");
	      else
	         System.out.println(str+" is not a palindrome");
	 sc.close();
	   }
}
