package problem13;

public class Books {
 void createBooks() {
	Book bk[]=new Book[2];
	bk[0]= new Book("Java Programming", 250.00);
	bk[1]=new Book("Let Us C    ", 200.00);
	for(int i=0;i<bk.length;i++) {
		bk[i].display();
		//System.out.println(bk[i]);
	}
}
void showBooks() {
	createBooks();
}
public static void main(String[] args) {
	Books b1= new Books();
	b1.showBooks();
}
}
