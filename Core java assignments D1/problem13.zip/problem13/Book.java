package problem13;

public class Book {
String book_title;
double book_prize;
public Book(String book_title, double book_prize) {
	this.book_title=book_title;
	this.book_prize=book_prize;
	// TODO Auto-generated constructor stub
}
public String getBook_title() {
	return book_title;
}
public void setBook_title(String book_title) {
	this.book_title = book_title;
}
public double getBook_prize() {
	return book_prize;
}
public void setBook_prize(double book_prize) {
	this.book_prize = book_prize;
}
void display() {
	System.out.print("\t |Book Title: "+this.book_title);
	System.out.println("\t |Book Prize: "+this.book_prize+"|");
}
}
