package problem73;

public class Main {

}
