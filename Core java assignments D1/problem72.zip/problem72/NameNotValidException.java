package problem72;

public class NameNotValidException {

}
