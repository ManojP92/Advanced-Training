package problem72;

public class Student {

}
