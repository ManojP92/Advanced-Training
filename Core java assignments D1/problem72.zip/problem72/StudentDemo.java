package problem72;

public class StudentDemo {

}
