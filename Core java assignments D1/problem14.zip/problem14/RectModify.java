package problem14;

import java.util.Scanner;

public class RectModify {
private float l=1;
private float b=1;
float area;
float perimeter;

public float getL() {
	return l;
}

public void setL(float l) {
	if(l<0.0 || l>20.0) {
		System.out.println("Enter value less than20.0 and greater than 0.0");
	}
	else {
	this.l=l;
	}
	
}

public float getB() {
	return b;
}
public void setB(float b) {
	if(b<0.0 || b>20.0) {
		System.out.println("Enter value less than20.0 and greater than 0.0");
	}
	else {
	this.b = b;
	}
}

void input() { 
	 Scanner sc = new Scanner(System.in) ;
		System.out.println("Enter Length: ");
		l=sc.nextFloat();
		System.out.println("Enter Width: ");
		b=sc.nextFloat();
	}

void areaval() {
	area=l*b;
}
void perivalue() {
	perimeter=2*(l+b);
}

void display() {
	System.out.println("The area of rectangle is: "+area);
	System.out.println("The perimeter of rectangle is: "+perimeter);
}

}
