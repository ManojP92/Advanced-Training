package problem82;

public class AddSynchronization {

}
