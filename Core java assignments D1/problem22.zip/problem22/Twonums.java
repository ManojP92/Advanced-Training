package problem22;

public class Twonums {
public static void main(String[] args) {
	int x=Integer.parseInt(args[0]);
	int y=Integer.parseInt(args[1]);
	int z=x+y;int previous=y;
	System.out.println(x+"\t"+y+"\t");
	for(int i=0;i<13;i++) {
		
		System.out.print(z+"\t");
		int temppre=z;
		z=z+previous;
		previous=temppre;
	}
	
}
}
