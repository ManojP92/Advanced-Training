package problem81;

public class Counter {

}
