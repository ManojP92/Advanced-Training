package problem31;

public abstract class Instrument {
	public abstract void play();
}
