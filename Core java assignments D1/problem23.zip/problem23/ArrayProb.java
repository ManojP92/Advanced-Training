package problem23;

public class ArrayProb {
 int s=0;
float av=0;
int small=0;

 int A[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};

 int sum(int A[]) { 
	for(int i=0;i<=14;i++) {
		 s=A[i]+s;
	}
	return s;
}

float avg(int sum) {
	//ArrayProb obj=new ArrayProb();
	av=sum;
	av=av/14;
	return av;
}

int smallest(int A[]) {
	for(int i=0;i<=14;i++) {
		int j=i+1;
		if(A[i]<A[j]) {
			small=A[i];}
		else {
			small=A[j];}
			}
	return small;
	}

float insert(int i) {
	 float f1=(int)A[i];
	 return f1;
}

public static void main(String[] args) {
	//float b[]=new float[18];
	int A[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
	 float b[];
	 b=new float[18];
	ArrayProb obj= new ArrayProb();
	int sum1=obj.sum(A);
	float average=obj.avg(sum1);
	int sm=obj.smallest(A);
	for(int i=0;i<=15;i++) {
		if(i<=14) {
		 b[i]=(float) A[i] ;}
		else {
			b[15]=sum1;
			b[16]=average;
			b[17]=sm;
		}
	}
	for(int k=0;k<=17;k++) {
		System.out.print("\t "+b[k]);
	}
}

}
