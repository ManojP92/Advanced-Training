package problem71;

public class FileCopy {

}
