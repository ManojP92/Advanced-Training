package problem12;

import java.util.Scanner;

public class Rectangle {
private int l;
private int b;
int a;
/**
 * @param l
 * @param b
 */
public Rectangle(int l, int b) {
	super();
	this.l = l;
	this.b = b;
}
public Rectangle() {
	// TODO Auto-generated constructor stub
}
public int getL() {
	return l;
}
public void setL(int l) {
	this.l = l;
}
public int getB() {
	return b;
}
public void setB(int b) {
	this.b = b;
}
 void input()
 {
	 try (Scanner sc = new Scanner(System.in)) {
		System.out.println("Enter Length: ");
		 l= sc.nextInt();
		 System.out.println("Enter Bredth: ");
		 b=sc.nextInt();
	}
	 
 }
 void calc() {
	 a=l*b;
 }
 void display()
 {
	 System.out.println("The area of rectangle is: "+a);
 }

}
