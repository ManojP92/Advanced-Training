package problem12;

public class TestRectangle {

public static void main(String[] args) {
	Rectangle obj1= new Rectangle();
	System.out.println("_____RECTANGLE-1 |__|");
	obj1.input();
	obj1.calc();
	obj1.display();
	System.out.println("_____RECTANGLE-1 |__|\n");
	Rectangle obj2= new Rectangle();
	System.out.println("_____RECTANGLE-2 |__|");
	obj2.input();
	obj2.calc();
	obj2.display();
	System.out.println("_____RECTANGLE-2 |__|\n");
	Rectangle obj3= new Rectangle();
	System.out.println("_____RECTANGLE-3 |__|");
	obj3.input();
	obj3.calc();
	obj3.display();
	System.out.println("_____RECTANGLE-3 |__|\n");
	Rectangle obj4= new Rectangle();
	System.out.println("_____RECTANGLE-4 |__|");
	obj4.input();
	obj4.calc();
	obj4.display(); 
	System.out.println("_____RECTANGLE-4 |__|\n");
	Rectangle obj5= new Rectangle();
	System.out.println("_____RECTANGLE-5 |__|");
	obj5.input();
	obj5.calc();
	obj5.display();
	System.out.println("_____RECTANGLE-5 |__|");
}
}
